package com.example.exam.model.enums;

public enum CategoryEnum {
    BATTLE, CARGO, PATROL
}
