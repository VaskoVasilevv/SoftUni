package com.example.xml.util;

public interface ValidationUtil {
    public <T> boolean isValid(T entity);
}
