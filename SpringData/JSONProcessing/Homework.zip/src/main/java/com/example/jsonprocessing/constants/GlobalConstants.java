package com.example.jsonprocessing.constants;

public class GlobalConstants {

    //  TODO Check file path.
    public static final String RESOURCES_FILE_PATH = "D:\\SoftUniGit\\src\\SpringData\\JSONProcessing\\src\\main\\resources\\json\\";
    public static final String OUTPUT_PATH = "D:\\SoftUniGit\\src\\SpringData\\JSONProcessing\\src\\main\\resources\\json\\out\\";

}
