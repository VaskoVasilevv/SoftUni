package com.example.football.models.enums;

public enum Position {
    ATT,MID,DEF
}
